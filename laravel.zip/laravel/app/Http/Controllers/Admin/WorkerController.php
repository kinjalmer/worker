<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Notifications\Notifiable;
use Illuminate\Auth\Passwords\CanResetPassword;
use Illuminate\Foundation\Auth\SendsPasswordResetEmails;
use Illuminate\Auth\Events\PasswordReset;
use App\User;
use File;
use Intervention\Image\ImageManagerStatic as Image;
use Auth;
use App\Role;
use App\RoleUser;
class WorkerController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
	 use SendsPasswordResetEmails;
    public function __construct()
    {
        $this->middleware('auth');


    }
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */

    public function saveworkerorder(Request $request){
        $orders = $request->orders;
        // echo "<pre>";
        // print_r($orders);
        asort($orders);
        // print_r($orders);
        // exit;
        $key =1;
        foreach($orders as $id=>$order){
             $worker = User::find($id);
             $worker->order_by = $key;
             $worker->save();
             $key++;
         }
        return redirect('/admin/worker/index');
    }
    public function update(Request $request){
        $status_value = $request->status_value;
        $row_ids = $request->row_id;

        if($status_value!='delete'){
            $status = $status_value == 'active' ? 1 : 2;
        }
        if($row_ids != null){
            foreach($row_ids as $row_id){
                $worker = User::findorfail($row_id);
                if($status_value!='delete'){
                    $worker->is_active = $status;
                    $worker->save();
                }else{
                    $worker->delete();
                }
            }
            return redirect()->intended('admin/worker/index')
            ->with('success','worker '. $status_value .'  successfully!');
        }
        else{
            return redirect()->back()->with('error','Please select value.');
        }


    }

    public function index(Request $request){

        if (Auth::user()) {
            $user_type = Auth::user()->user_type;
            if ($user_type == 2) {
                return redirect()->route('dashboard');
            }
        }

        $status = 11;
        $searchText = $request->searchText;
        $sortDirection = $request->sortDirection ? $request->sortDirection : 'asc';
        $sort = $request->sort ? $request->sort : 'order_by';
        if($request->status){
            $status = $request->status;
        }
       $worker_id = $request->worker_id;

        $workers = User::where(function($query) use($searchText,$status, $worker_id) {
            if($searchText){
                $query->where('name','like', '%' .$searchText . '%' )
                     ->orwhere('email','like', '%' .$searchText . '%' )
                     ->orwhere('gender','like', '%' .$searchText . '%' );

            }
            if($status == 0 || $status == 1 && $status !=""){
                     $query->where('status',$status);
            }
            if($worker_id!=null){
                $query->where('id',$worker_id);
             }
            })
            ->where('user_type',2)
            ->where('id','<>',Auth::user()->id)
            ->orderBy($sort,$sortDirection)
            ->paginate(15);

       return view('admin.worker.index',[
           'workers'=> $workers,
           'sort'=>$sort,
           'searchText'=>$searchText,
           'sortDirection'=>$sortDirection,
           'status' =>$status
           ]);

    }
    public function createworker(){
        $roles = Role::where('is_active','1')->orderby('order_by','asc')->get();
        return view('admin.worker.createworker',[
            'roles' => $roles
        ]);
    }

    public function storeworker(Request $request){
        $this->userValidate($request);

        $data = $request->only( 'name','email','password','gender','is_active','order_by' );






        $worker = User::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => bcrypt($data['password']),
            'gender' => $data['gender'],
            'user_type' => 2,
            'is_active' => 1,
            'status' => 1,
            'order_by' => @$data['order_by'],
            'image' => @$data['image'],
        ]);





        $image = $request->file('image');


        if ($image) {

            $imagename = time() . '.' . $image->getClientOriginalExtension();

            $destinationPath = public_path('/image/worker');

            if (!File::exists($destinationPath)) {
                File::makeDirectory($destinationPath, $mode = 0777, true, true);
                File::makeDirectory($destinationPath . '/100', $mode = 0777, true, true);
                File::makeDirectory($destinationPath . '/500', $mode = 0777, true, true);
            }

            $path = public_path('image/worker' . '/100/' . $worker->id . "_" . $imagename);
            Image::make($image->getRealPath())->resize(100, 100)->save($path);

            $path = public_path('image/worker' . '/500/' . $worker->id . "_" . $imagename);
            Image::make($image->getRealPath())->resize(500, 500)->save($path);



            $worker->image = $worker->id . "_" . $imagename;


            $worker->save();
        }

        // $roles = $request->role;
        // if(is_array($roles) && count($roles) > 0){
        // foreach($roles as $role){
        //    RoleUser::create([
        //        'role_id' => $role,
        //        'worker_id' => $worker->id
        //    ]);
        // }
        // }

        return redirect('/admin/worker/index');

    }


    public function editworker($id){

        $worker = User::find($id);
        $roles = Role::where('is_active','1')->orderby('order_by','asc')->get();
        return view('admin.worker.editworker',[
                    'worker' => $worker,
                    'roles' => $roles
            ]);
    }

    public function updateworker(Request $request ){


        $validation = $request->validate([
            'id' => 'required',
            'name' => 'required',
            'email' => 'required',
            'gender' => 'required',
            'password_confirmation'=>'same:password'
        ]);



        $id = $request->id;
        $worker = User::find($id);

        $worker->name = $request->name;
        $worker->email = $request->email;
        $worker->order_by = $request->order_by;
        if($request->password){
            $worker->password = bcrypt($request->password);
        }



        $worker->gender = $request->gender;

        $worker->is_active = $request->is_active;

        $worker->save();


        $image = $request->file('image');


        if ($image) {

            $imagename = time() . '.' . $image->getClientOriginalExtension();

            $destinationPath = public_path('/image/worker');

            if (!File::exists($destinationPath)) {
                File::makeDirectory($destinationPath, $mode = 0777, true, true);
                File::makeDirectory($destinationPath . '/100', $mode = 0777, true, true);
                File::makeDirectory($destinationPath . '/500', $mode = 0777, true, true);
            }

            $path = public_path('image/worker' . '/100/' . $worker->id . "_" . $imagename);
            Image::make($image->getRealPath())->resize(100, 100)->save($path);

            $path = public_path('image/worker' . '/500/' . $worker->id . "_" . $imagename);
            Image::make($image->getRealPath())->resize(500, 500)->save($path);



            $worker->image = $worker->id . "_" . $imagename;


            $worker->save();
        }

        $worker->userroles()->delete();
    //    foreach($user->userroles as $role){
    //     $role->delete();
    //    }
        $roles = $request->role;
        if(is_array($roles) && count($roles) > 0){
            foreach($roles as $role){
                RoleUser::create([
                    'role_id' => $role,
                    'worker_id' => $worker->id
                ]);
             }
        }



        return redirect('/admin/worker/index');
    }
    public function deleteworker($id){


        $worker = User::findorfail($id);

        $worker->delete();

        return redirect()->intended('admin/worker/index')->with('success','Worker Deleted successfully!');

    }
    public function publishworker($id){
        $worker = User::find($id);
        $worker->is_active = 1;
        $worker->save();
        return redirect()->intended('admin/worker/index')->with('success','Worker Published  successfully!');
    }

    public function unpublishworker($id){
        $worker = User::find($id);
        $worker->is_active = 0;
        $worker->save();
        return redirect()->intended('admin/worker/index')->with('success','worker Unpublished  successfully!');
    }
    public  function userValidate(Request $request){
        $validation = $request->validate([
            'name' => 'required',
            'email' => 'required|unique:users|email',
            //'password' => 'required|min:8|regex:/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{6,}$/',
            'password' => 'required|min:5',
            //'order_by' => 'required|numeric'
        ]);
    }




}


