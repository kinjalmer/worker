<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use App\Notifications\ResetPassword as ResetPasswordNotification;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\HasRoles;
class Worker extends Authenticatable
{
    use Notifiable;
    use SoftDeletes;
    use  HasRoles;
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password', 'dob', 'gender','user_type','is_active','order_by'    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];


    protected $dates = [
        'created_at',
        'updated_at',
        'dob',
        'deleted_at',
    ];


    public function userroles(){

        return $this->hasMany("App\RoleUser","user_id" ,"id");
    }


    public function sendPasswordResetNotification($token)
    {
        // Your your own implementation.
        $this->notify(new ResetPasswordNotification($token));
    }

    // public function roles(){

    //     return $this->hasMany("App\RoleUser","user_id" ,"id");
    // }




    public function role()
    {
        return $this->belongsToMany('App\Role','role_user','user_id','role_id');
    }
}
