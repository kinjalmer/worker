<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Notifications\Notifiable;

use Illuminate\Auth\Passwords\CanResetPassword;
use Illuminate\Foundation\Auth\SendsPasswordResetEmails;
use Illuminate\Auth\Events\PasswordReset;
use Auth;
use App\User;


class WorkerLoginController extends Controller
{
    use SendsPasswordResetEmails;


    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //$this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
	  public function index()
    {
        $user = Auth::user();
        if($user){
            return redirect()->route('dashboard');
        }
        return view('auth.login');
    }

    public function workerlogin(Request $request)
    {
        $credentials = $request->only('email', 'password');
        if (Auth::attempt($credentials)) {
            $worker = User::where('email',$request->email)->first();

            if($worker->status == 1)
            {

                    return redirect()->route('dashboard');
            }

	   }

       return redirect()->route('adminlogin')->with('error','Your account is not activated.');

    }
    public function logout(){
        Auth::logout();

        return redirect()->route('adminlogin');
    }
   public function signupworker(Request $request)
    {
		  $data = $request->all();
		  $validation = $request->validate([
            'name' => 'required',
			'last_name' => 'required',
			'mobile' => 'required',
			'gender' => 'required',
            'email' => 'required|unique:users|email',
            'password' => 'required|min:6',

        ]);
		$worker = User::create([
            'name' => $data['name'],
			'last_name' => $data['last_name'],
            'email' => $data['email'],
            'password' => bcrypt($data['password']),
            'gender' => $data['gender'],
            'user_type' => 2,
            'is_active' => 0,
            'order_by' => 0,
			'api_token' => md5(uniqid()),
			'activation_token' => sha1(time() . uniqid() . $data['email']),
            'activation_time' => \Carbon\Carbon::now(),
        ]);

		$worker->notify(new \App\Notifications\ActivationLink($worker));
		return redirect()->back()->with('success','Register Successfully Please check email to activate your account!');
	}
	public function activateaccount(Request $request){

		$worker = User::where('activation_token',$request->token)->where('status',0)->where('is_active',0)->first();
		if($worker){
			$worker->is_active = 1;
			$worker->status = 1;
			$worker->activation_token = null;
			$worker->activation_time = null;
			$worker->save();
			$worker->notify(new \App\Notifications\VerifiedEmail($worker));
			return redirect()->route('adminlogin')->with('success','Congratulation, your account has been successfully verified.Please login.');
		}
		else{
			return redirect()->route('adminlogin')->with('error','Already activated or account is deleted');
		}

	}
    public function showLinkRequestForm(Request $request){

             return view('worker.resetpassword');
         }
    public function showResetForm(Request $request, $token = null)
    {

        return view('admin.reset')->with(
            ['token' => $token, 'email' => $request->email]
        );
    }
}

