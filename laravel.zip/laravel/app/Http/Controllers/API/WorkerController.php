<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\ScheduleJobs;
use App\User;
use Auth;
use Carbon\Carbon;
use Illuminate\Http\Request;

class WorkerController extends Controller
{

    public function listofworkerjobs(Request $request)
    {

        $data = array();
        $formlist = array();
        $status = 0;
        $formsubmittedtotal = 0;
        $limit = $request->limit;

        $total_jobs = ScheduleJobs::select('schedulejobs.*')
            ->join('jobworkers', 'schedulejobs.id', '=', 'jobworkers.schedule_job_id')
            ->where('jobworkers.worker_id', Auth::user()->id)
            ->get()->count();
        $total_jobs = ($total_jobs != null) ? $total_jobs : 0;

        $pending_jobs = ScheduleJobs::select('schedulejobs.id', 'job_title as title', 'job_description as description', 'start_date', 'end_date', 'priority')->join('jobworkers', 'schedulejobs.id', '=', 'jobworkers.schedule_job_id')
            ->where('jobworkers.worker_id', Auth::user()->id)
            ->where('schedulejobs.is_active', 0)
            ->where('schedulejobs.start_date', '<', Carbon::now())
            ->orderBy('schedulejobs.id', 'desc')->limit(5)->get();
        $pending_jobs = notnullvalue($pending_jobs);
        foreach ($pending_jobs as &$pending_job) {
            $pending_job['date'] = date('D, jS M', strtotime($pending_job['start_date'])) . " to " . date('jS M', strtotime($pending_job['end_date']));
            $workers = [];
            $workers[] = array('id' => Auth::user()->id, 'name' => Auth::user()->name, 'image' => asset('/image/worker/100/' . Auth::user()->image));
            $workers = notnullvalue($workers);
            $pending_job['workers'] = $workers;
            unset($pending_job['start_date']);
            unset($pending_job['end_date']);
        }

        $pending_jobs = ($pending_jobs != "") ? $pending_jobs : 0;
        $pending = array("pending_jobs" => array("header" => "Pending Jobs", "subheader" => "Total " . count($pending_jobs) . " jobs", "image" => asset('/image/pendingjob.png'), "data" => $pending_jobs));

        $form_data = array("forms" => array("header" => "Analytics \u0026 Reporting", "subheader" => "View all pending \u0026 submitted forms", "image" => asset('/image/form.png'), "data" => $forms));

        $completed_jobs = ScheduleJobs::select('schedulejobs.*')
            ->join('jobworkers', 'schedulejobs.id', '=', 'jobworkers.schedule_job_id')
            ->where('jobworkers.worker_id', Auth::user()->id)
            ->where('schedulejobs.is_active', 1)
            ->orderBy('schedulejobs.id', 'desc')->limit(5)->get();
        $completed_jobs = notnullvalue($completed_jobs);
        foreach ($completed_jobs as &$completed_job) {
            $completed_job['date'] = date('D, jS M', strtotime($completed_job['start_date'])) . " to " . date('jS M', strtotime($completed_job['end_date']));
            $workers = [];
            $workers[] = array('id' => Auth::user()->id, 'name' => Auth::user()->name, 'image' => asset('/image/worker/100/' . Auth::user()->image));
            $workers = notnullvalue($workers);
            $completed_job['workers'] = $workers;
            unset($completed_job['start_date']);
            unset($completed_job['end_date']);

        }
        $completed_jobs = ($completed_jobs != "") ? $completed_jobs : 0;
        $complete = array("complete_jobs" => array("header" => "Completed Jobs", "subheader" => "Total " . count($completed_jobs) . " jobs", "image" => asset('/image/completejob.png'), "data" => $completed_jobs));

        $upcoming_jobs = ScheduleJobs::select('schedulejobs.id', 'start_date as date', 'job_title as title', 'job_description as description', 'priority')->
            join('jobworkers', 'schedulejobs.id', '=', 'jobworkers.schedule_job_id')
            ->where('jobworkers.worker_id', Auth::user()->id)
            ->where('schedulejobs.start_date', '>', Carbon::now())
            ->orderBy('schedulejobs.id', 'desc')->limit(5)->get();
        $upcoming_jobs = notnullvalue($upcoming_jobs);
        foreach ($upcoming_jobs as &$upcoming_job) {
            $upcoming_job['date'] = date('D, jS M Y', strtotime($upcoming_job['date']));
            $workers = [];
            $workers[] = array('id' => Auth::user()->id, 'name' => Auth::user()->name, 'image' => asset('/image/worker/100/' . Auth::user()->image));
            $workers = notnullvalue($workers);
            $upcoming_job['workers'] = $workers;
            unset($upcoming_job['start_date']);
            unset($upcoming_job['end_date']);

        }
        $upcoming_jobs = ($upcoming_jobs != "") ? $upcoming_jobs : 0;
        $upcoming = array("upcoming_jobs" => array("header" => "Upcoming Jobs", "subheader" => "Total " . count($upcoming_jobs) . " jobs", "image" => asset('/image/upcomingjob.png'), "data" => $upcoming_jobs));

        $formsubmittedtotal = ScheduleJobs::select('schedulejobs.*')->join('jobform', 'schedulejobs.id', '=', 'jobform.job_id')->where('worker_id', Auth::user()->id)
            ->get()->count();
        $status = 1;
        $data = array($pending, $form_data, $upcoming);

        return response()->json(['status' => $status, 'response' => $data]);
        exit;
    }

}
