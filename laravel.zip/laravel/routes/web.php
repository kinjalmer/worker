<?php



Route::post('/signupworker', 'Admin\AdminController@signupworker')->name('signupworker');
Route::get('activate-account', 'Admin\AdminController@activateaccount')->name('activateaccount');
Route::get('/', 'Admin\AdminController@index')->name('adminlogin');
Route::get('/user/login', 'Admin\AdminController@index')->name('adminlogin');
Route::get('admin', 'Admin\AdminController@index')->name('admin');
Route::post('/user/login', 'Admin\AdminController@login')->name('adminlogin');
Route::get('dashboard', 'Admin\DashboardController@index')->name('dashboard');
Route::get('logout', 'Admin\AdminController@logout')->name('adminlogout');


/* Route::get('/', 'Admin\WorkerLoginController@index')->name('workerlogin');
Route::get('/login', 'Admin\AdminController@index')->name('adminlogin');
Route::post('/workerlogin', 'Admin\WorkerLoginController@workerlogin')->name('workerlogin');
Route::get('/workerlogout', 'Admin\WorkerLoginController@logout')->name('workerlogout'); */

Route::get('/resetpassword', 'Admin\AdminController@showLinkRequestForm')->name('admin.resetpassword');
Route::post('/email', 'Admin\AdminController@sendResetLinkEmail')->name('admin.password.email');
Route::get('/reset/{token}', 'Admin\AdminController@showResetForm')->name('admin.password.reset.token');
Route::post('/resetpass', 'Admin\AdminResetsPasswords@reset')->name('admin.password.resetpass');

/* Route::get('/resetpassword', 'Admin\WorkerController@showLinkRequestForm')->name('worker.resetpassword');
Route::post('/email', 'Admin\WorkerController@sendResetLinkEmail')->name('worker.password.email');
Route::get('/reset/{token}', 'Admin\WorkerController@showResetForm')->name('worker.password.reset.token');
Route::post('/resetpass', 'Admin\WorkerResetsPasswords@reset')->name('worker.password.resetpass'); */


Auth::routes();

Route::get('/admin/user/index', 'Admin\UserController@index')->name('admin.user');
Route::post('/admin/user/index', 'Admin\UserController@index')->name('admin.searchuser');
Route::get('/admin/user/createuser', 'Admin\UserController@createuser')->name('admin.createuser');
Route::post('/admin/user/storeuser', 'Admin\UserController@storeuser')->name('admin.storeuser');
Route::get('/admin/user/edituser/{id}', 'Admin\UserController@edituser')->name('admin.edituser');
Route::post('/admin/user/updateuser', 'Admin\UserController@updateuser')->name('admin.updateuser');
Route::get('/admin/user/deleteuser/{id}', 'Admin\UserController@deleteuser')->name('admin.deleteuser');
Route::get('/admin/user/unpublishuser/{id}', 'Admin\UserController@unpublishuser')->name('admin.unpublishuser');
Route::get('/admin/user/publishuser/{id}', 'Admin\UserController@publishuser')->name('admin.publishuser');
Route::post('/admin/user/update', 'Admin\UserController@update')->name('admin.update');
Route::post('/admin/user/saveuserorder', 'Admin\UserController@saveuserorder')->name('admin.saveuserorder');

Route::get('/admin/worker/index', 'Admin\WorkerController@index')->name('admin.worker');
Route::post('/admin/worker/index', 'Admin\WorkerController@index')->name('admin.searchworker');
Route::get('/admin/worker/createworker', 'Admin\WorkerController@createworker')->name('admin.createworker');
Route::post('/admin/worker/storeworker', 'Admin\WorkerController@storeworker')->name('admin.storeworker');
Route::get('/admin/worker/editworker/{id}', 'Admin\WorkerController@editworker')->name('admin.editworker');
Route::post('/admin/worker/updateworker', 'Admin\WorkerController@updateworker')->name('admin.updateworker');
Route::get('/admin/worker/deleteworker/{id}', 'Admin\WorkerController@deleteworker')->name('admin.deleteworker');
Route::get('/admin/worker/unpublishworker/{id}', 'Admin\WorkerController@unpublishworker')->name('admin.unpublishworker');
Route::get('/admin/worker/publishworker/{id}', 'Admin\WorkerController@publishworker')->name('admin.publishworker');
Route::post('/admin/worker/update', 'Admin\WorkerController@update')->name('admin.update');
Route::post('/admin/worker/saveworkerorder', 'Admin\WorkerController@saveworkerorder')->name('admin.saveworkerorder');


Route::get('/admin/contact/index', 'Admin\SystemController@index')->name('admin.contact');
Route::post('/admin/contact/index', 'Admin\SystemController@index')->name('admin.contact');
Route::get('/admin/contact/create', 'Admin\SystemController@create')->name('admin.contact.create');
Route::post('/admin/contact/store', 'Admin\SystemController@store')->name('admin.contact.store');
Route::get('/admin/contact/edit/{id}', 'Admin\SystemController@edit')->name('admin.contact.edit');
Route::post('/admin/contact/update', 'Admin\SystemController@update')->name('admin.contact.update');


Route::get('/admin/master/index', 'Admin\SystemController@index')->name('admin.master');
Route::post('/admin/master/index', 'Admin\SystemController@index')->name('admin.master');
Route::get('/admin/master/create', 'Admin\SystemController@create')->name('admin.master.create');
Route::post('/admin/master/store', 'Admin\SystemController@store')->name('admin.master.store');
Route::get('/admin/master/edit/{id}', 'Admin\SystemController@edit')->name('admin.master.edit');
Route::post('/admin/master/update', 'Admin\SystemController@update')->name('admin.master.update');

Route::get('/admin/masterfield/{master_id}/index', 'Admin\FieldController@index')->name('admin.masterfield');
Route::post('/admin/masterfield/{master_id}/index', 'Admin\FieldController@index')->name('admin.masterfield');
Route::get('/admin/masterfield/{master_id}/create', 'Admin\FieldController@create')->name('admin.masterfield.create');
Route::post('/admin/masterfield/store', 'Admin\FieldController@store')->name('admin.masterfield.store');
Route::get('/admin/masterfield/edit/{id}', 'Admin\FieldController@edit')->name('admin.masterfield.edit');
Route::post('/admin/masterfield/update', 'Admin\FieldController@update')->name('admin.masterfield.update');
//Route::get('/admin/masterfield/{id}/delete/{field}', 'Admin\FieldController@delete')->name('admin.masterfield.delete');

Route::get('/admin/testimonial/index', 'Admin\SystemController@index')->name('admin.testimonial');
Route::post('/admin/testimonial/index', 'Admin\SystemController@index')->name('admin.testimonial');
Route::get('/admin/testimonial/create', 'Admin\SystemController@create')->name('admin.testimonial.create');
Route::post('/admin/testimonial/store', 'Admin\SystemController@store')->name('admin.testimonial.store');
Route::get('/admin/testimonial/edit/{id}', 'Admin\SystemController@edit')->name('admin.testimonial.edit');
Route::post('/admin/testimonial/update', 'Admin\SystemController@update')->name('admin.testimonial.update');

Route::get('/admin/category/index', 'Admin\CategoryController@index')->name('admin.category');
Route::post('/admin/category/index', 'Admin\CategoryController@index')->name('admin.category');
Route::get('/admin/category/create', 'Admin\CategoryController@create')->name('admin.category.create');
Route::post('/admin/category/store', 'Admin\CategoryController@store')->name('admin.category.store');
Route::get('/admin/category/edit/{id}', 'Admin\CategoryController@edit')->name('admin.category.edit');
Route::post('/admin/category/update', 'Admin\CategoryController@update')->name('admin.category.update');



Route::get('/admin/article/index', 'Admin\ArticleController@index')->name('admin.article');
Route::post('/admin/article/index', 'Admin\ArticleController@index')->name('admin.article');
Route::get('/admin/article/create', 'Admin\ArticleController@create')->name('admin.article.create');
Route::post('/admin/article/store', 'Admin\ArticleController@store')->name('admin.article.store');
Route::get('/admin/article/edit/{id}', 'Admin\ArticleController@edit')->name('admin.article.edit');
Route::post('/admin/article/update', 'Admin\ArticleController@update')->name('admin.article.update');



Route::get('/admin/role/index', 'Admin\RoleController@index')->name('admin.role');
Route::post('/admin/role/index', 'Admin\RoleController@index')->name('admin.role');
Route::get('/admin/role/create', 'Admin\RoleController@create')->name('admin.role.create');
Route::post('/admin/role/store', 'Admin\RoleController@store')->name('admin.role.store');
Route::get('/admin/role/edit/{id}', 'Admin\RoleController@edit')->name('admin.role.edit');
Route::post('/admin/role/update', 'Admin\RoleController@update')->name('admin.role.update');

Route::get('/admin/permission/index', 'Admin\SystemController@index')->name('admin.permission');
Route::post('/admin/permission/index', 'Admin\SystemController@index')->name('admin.permission');
Route::get('/admin/permission/create', 'Admin\SystemController@create')->name('admin.permission.create');
Route::post('/admin/permission/store', 'Admin\SystemController@store')->name('admin.permission.store');
Route::get('/admin/permission/edit/{id}', 'Admin\SystemController@edit')->name('admin.permission.edit');
Route::post('/admin/permission/update', 'Admin\SystemController@update')->name('admin.permission.update');



        /* Generated By Jeny Module*/
        Route::get('/admin/naksh/index', 'Admin\SystemController@index')->name('admin.naksh');
Route::post('/admin/naksh/index', 'Admin\SystemController@index')->name('admin.naksh');
Route::get('/admin/naksh/create', 'Admin\SystemController@create')->name('admin.naksh.create');
Route::post('/admin/naksh/store', 'Admin\SystemController@store')->name('admin.naksh.store');
Route::get('/admin/naksh/edit/{id}', 'Admin\SystemController@edit')->name('admin.naksh.edit');
Route::post('/admin/naksh/update', 'Admin\SystemController@update')->name('admin.naksh.update');
        /* Generated By Jeny Module*/



Route::get('/home', 'Admin\DashboardController@index')->name('home');
//Route::get('/admin/dashboard', 'Admin\DashboardController@index')->name('dashboard');

        /* Generated By Jeny Module*/
        Route::get('/admin/setting/index', 'Admin\SystemController@index')->name('admin.setting');
Route::post('/admin/setting/index', 'Admin\SystemController@index')->name('admin.setting');
Route::get('/admin/setting/create', 'Admin\SystemController@create')->name('admin.setting.create');
Route::post('/admin/setting/store', 'Admin\SystemController@store')->name('admin.setting.store');
Route::get('/admin/setting/edit/{id}', 'Admin\SystemController@edit')->name('admin.setting.edit');
Route::post('/admin/setting/update', 'Admin\SystemController@update')->name('admin.setting.update');
        /* Generated By Jeny Module*/


/* Generated By Jeny Module*/
Route::get('/admin/product/index', 'Admin\SystemController@index')->name('admin.product');
Route::post('/admin/product/index', 'Admin\SystemController@index')->name('admin.product');
Route::get('/admin/product/create', 'Admin\SystemController@create')->name('admin.product.create');
Route::post('/admin/product/store', 'Admin\SystemController@store')->name('admin.product.store');
Route::get('/admin/product/edit/{id}', 'Admin\SystemController@edit')->name('admin.product.edit');
Route::post('/admin/product/update', 'Admin\SystemController@update')->name('admin.product.update');
/* Generated By Jeny Module*/



Route::get('/admin/faq/index', 'Admin\SystemController@index')->name('admin.faq');
Route::post('/admin/faq/index', 'Admin\SystemController@index')->name('admin.faq');
Route::get('/admin/faq/create', 'Admin\SystemController@create')->name('admin.faq.create');
Route::post('/admin/faq/store', 'Admin\SystemController@store')->name('admin.faq.store');
Route::get('/admin/faq/edit/{id}', 'Admin\SystemController@edit')->name('admin.faq.edit');
Route::post('/admin/faq/update', 'Admin\SystemController@update')->name('admin.faq.update');


Route::get('/admin/form/index', 'Admin\FormController@index')->name('admin.form');
Route::post('/admin/form/index', 'Admin\FormController@index')->name('admin.form');
Route::get('/admin/form/create', 'Admin\FormController@create')->name('admin.form.create');
Route::post('/admin/form/store', 'Admin\FormController@store')->name('admin.form.store');
Route::get('/admin/form/edit/{id}', 'Admin\FormController@edit')->name('admin.form.edit');
Route::post('/admin/form/update', 'Admin\FormController@update')->name('admin.form.update');

Route::get('/admin/formcategories/index', 'Admin\SystemController@index')->name('admin.formcategories');
Route::post('/admin/formcategories/index', 'Admin\SystemController@index')->name('admin.formcategories');
Route::get('/admin/formcategories/create', 'Admin\SystemController@create')->name('admin.formcategories.create');
Route::post('/admin/formcategories/store', 'Admin\SystemController@store')->name('admin.formcategories.store');
Route::get('/admin/formcategories/edit/{id}', 'Admin\SystemController@edit')->name('admin.formcategories.edit');
Route::post('/admin/formcategories/update', 'Admin\SystemController@update')->name('admin.formcategories.update');


Route::get('/admin/schedulejob/index', 'Admin\ScheduleJobController@index')->name('admin.schedulejob');
Route::post('/admin/schedulejob/index', 'Admin\ScheduleJobController@index')->name('admin.schedulejob.search');
Route::get('/admin/schedulejob/create', 'Admin\ScheduleJobController@create')->name('admin.schedulejob.create');
Route::post('/admin/schedulejob/store', 'Admin\ScheduleJobController@store')->name('admin.schedulejob.store');
Route::get('/admin/schedulejob/edit/{id}', 'Admin\ScheduleJobController@edit')->name('admin.schedulejob.edit');
Route::post('/admin/schedulejob/update', 'Admin\ScheduleJobController@update')->name('admin.schedulejob.update');
Route::get('/admin/schedulejob/delete/{id}', 'Admin\ScheduleJobController@delete')->name('admin.schedulejob.delete');
Route::get('/admin/schedulejob/unpublish/{id}', 'Admin\ScheduleJobController@unpublish')->name('admin.schedulejob.unpublish');
Route::get('/admin/schedulejob/publish/{id}', 'Admin\ScheduleJobController@publish')->name('admin.schedulejob.publish');
Route::post('/admin/schedulejob/saveschedulejoborder', 'Admin\ScheduleJobController@saveschedulejoborder')->name('admin.saveschedulejoborder');
Route::get('/admin/schedulejob/view/{id}', 'Admin\ScheduleJobController@viewjob')->name('admin.schedulejob.view');





Route::get('/admin/spports/index', 'Admin\SystemController@index')->name('admin.spports');
Route::post('/admin/spports/index', 'Admin\SystemController@index')->name('admin.spports');
Route::get('/admin/spports/create', 'Admin\SystemController@create')->name('admin.spports.create');
Route::post('/admin/spports/store', 'Admin\SystemController@store')->name('admin.spports.store');
Route::get('/admin/spports/edit/{id}', 'Admin\SystemController@edit')->name('admin.spports.edit');
Route::post('/admin/spports/update', 'Admin\SystemController@update')->name('admin.spports.update');





Route::get('/admin/support/index', 'Admin\SupportController@index')->name('admin.support');
Route::post('/admin/support/index', 'Admin\SupportController@index')->name('admin.support');
Route::get('/admin/support/create', 'Admin\SupportController@create')->name('admin.support.create');
Route::post('/admin/support/store', 'Admin\SupportController@store')->name('admin.support.store');
Route::get('/admin/support/edit/{id}', 'Admin\SupportController@edit')->name('admin.support.edit');
Route::post('/admin/support/update', 'Admin\SupportController@update')->name('admin.support.update');





Route::get('/admin/adminsupport/index', 'Admin\AdminSupportController@index')->name('admin.adminsupport');
Route::post('/admin/adminsupport/index', 'Admin\AdminSupportController@index')->name('admin.adminsupport');
Route::get('/admin/adminsupport/create', 'Admin\AdminSupportController@create')->name('admin.adminsupport.create');
Route::post('/admin/adminsupport/store', 'Admin\AdminSupportController@store')->name('admin.adminsupport.store');
Route::get('/admin/adminsupport/edit/{id}', 'Admin\AdminSupportController@edit')->name('admin.adminsupport.edit');
Route::post('/admin/adminsupport/update', 'Admin\AdminSupportController@update')->name('admin.adminsupport.update');





Route::get('/admin/Category/index', 'Admin\SystemController@index')->name('admin.Category');
Route::post('/admin/Category/index', 'Admin\SystemController@index')->name('admin.Category');
Route::get('/admin/Category/create', 'Admin\SystemController@create')->name('admin.Category.create');
Route::post('/admin/Category/store', 'Admin\SystemController@store')->name('admin.Category.store');
Route::get('/admin/Category/edit/{id}', 'Admin\SystemController@edit')->name('admin.Category.edit');
Route::post('/admin/Category/update', 'Admin\SystemController@update')->name('admin.Category.update');





Route::get('/admin/Categories/index', 'Admin\SystemController@index')->name('admin.Categories');
Route::post('/admin/Categories/index', 'Admin\SystemController@index')->name('admin.Categories');
Route::get('/admin/Categories/create', 'Admin\SystemController@create')->name('admin.Categories.create');
Route::post('/admin/Categories/store', 'Admin\SystemController@store')->name('admin.Categories.store');
Route::get('/admin/Categories/edit/{id}', 'Admin\SystemController@edit')->name('admin.Categories.edit');
Route::post('/admin/Categories/update', 'Admin\SystemController@update')->name('admin.Categories.update');



Route::get('/admin/jobform/index', 'Admin\JobformController@index')->name('admin.jobform');
Route::post('/admin/jobform/index', 'Admin\JobformController@index')->name('admin.jobform');
Route::get('/admin/jobform/create', 'Admin\JobformController@create')->name('admin.jobform.create');
Route::post('/admin/jobform/store', 'Admin\JobformController@store')->name('admin.jobform.store');
Route::get('/admin/jobform/edit/{id}', 'Admin\JobformController@edit')->name('admin.jobform.edit');
Route::post('/admin/jobform/update', 'Admin\JobformController@update')->name('admin.jobform.update');
Route::get('/admin/jobform/show/{formid}/{id}', 'Admin\JobformController@show')->name('admin.jobform.show');
Route::post('/admin/jobform/createpdf', 'Admin\JobformController@createpdf')->name('admin.jobform.createpdf');
Route::get('/downloadZip/{id}', 'Admin\JobformController@downloadZip')->name('admin.jobform.downloadZip');




Route::get('/admin/mytoolkit/index', 'Admin\MytoolkitController@index')->name('admin.mytoolkit');
Route::post('/admin/mytoolkit/index', 'Admin\MytoolkitController@index')->name('admin.mytoolkit');
Route::get('/admin/mytoolkit/create', 'Admin\MytoolkitController@create')->name('admin.mytoolkit.create');
Route::post('/admin/mytoolkit/store', 'Admin\MytoolkitController@store')->name('admin.mytoolkit.store');
Route::get('/admin/mytoolkit/edit/{id}', 'Admin\MytoolkitController@edit')->name('admin.mytoolkit.edit');
Route::post('/admin/mytoolkit/update', 'Admin\MytoolkitController@update')->name('admin.mytoolkit.update');
Route::get('/admin/mytoolkit/view/{id}', 'Admin\MytoolkitController@show')->name('admin.mytoolkit.view');


Route::get('/admin/assign/toolkit/form', 'Admin\MytoolkitController@assignform')->name('admin.mytoolkit.assignform');
Route::get('/admin/toolkit/list', 'Admin\AssigntoolkitlistController@listassigntoolkit')->name('admin.mytoolkit.assign.list');
Route::post('/admin/toolkit/list', 'Admin\AssigntoolkitlistController@listassigntoolkit')->name('admin.mytoolkit.assign.list');
Route::post('/admin/toolkit/deleteall', 'Admin\AssigntoolkitlistController@deletealltooltips')->name('admin.mytoolkit.assign.deleteall');
// Route::post('/admin/toolkit/delete', 'Admin\AssigntoolkitlistController@deletetoolkit')->name('admin.mytoolkit.deletetoolkit');



Route::get('/admin/contacts', 'Admin\ContactsController@index')->name('admin.contacts.index');
Route::post('/admin/contacts', 'Admin\ContactsController@index')->name('admin.mytoolkit.index');



