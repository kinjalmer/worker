<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});
Route::group(['prefix' => 'v1.0/',  'namespace' => 'Api'], function () {
    Route::post('login', 'UsersController@login');
    Route::post('register', 'UsersController@register');
    Route::get('activate-account', 'UsersController@activateAccount');

    Route::post('verifylink/resend', 'UsersController@resendAccountLink');
    Route::post('forgot-password', 'UsersController@forgotPassword');
    Route::post('reset-password', 'UsersController@resetPassword');

});
Route::group(['prefix' => 'v1.0/',  'namespace' => 'Api', 'middleware' => ['jwt.check','jwt.auth'] ], function () {

   // Route::post('change-status-worker', 'UsersController@changestatusofworker');
    Route::post('list-of-workers', 'UsersController@listofworkers');
    Route::post('list-of-forms', 'FormsController@listofforms');
    Route::get('get-profile', 'UsersController@getProfile');
    Route::post('update-profile', 'UsersController@updateProfile');
	Route::get('dashboard-list', 'DashboardController@listdata');
	Route::post('jobformsubmit', 'FormsController@jobform');
    Route::get('jobform-list', 'FormsController@jobformlist');
    Route::post('alljobs', 'JobsController@listofjobs');
    Route::post('allforms', 'JobsController@jobformlists');
    Route::post('formsubmit', 'JobsController@formsubmit');
    Route::get('contacts', 'ContactController@list');
    Route::get('toolkits', 'ToolkitsController@list');
    Route::post('toolkits/add', 'ToolkitsController@add');
    Route::post('toolkits/update', 'ToolkitsController@update');
    Route::post('toolkits/delete', 'ToolkitsController@delete');
    Route::post('jobforms', 'JobsController@formjoblists');
    Route::get('workerjobs', 'WorkerController@listofworkerjobs');
});
